MY MUSIC — PWA

To install this as an iPhone Home Screen app:
1. Upload all four files to any HTTPS static website host.
2. Open the site's URL in Safari on your iPhone.
3. Tap Share -> Add to Home Screen -> Add.
4. Launch "My Music" from the Home Screen.

Files:
- index.html
- manifest.json
- sw.js
- icon.svg

Important: iOS requires the site to be served over HTTPS for the PWA/service-worker installation to work. The downloaded HTML file from ChatGPT cannot itself provide that HTTPS origin.
